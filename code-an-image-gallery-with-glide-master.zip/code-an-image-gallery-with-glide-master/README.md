# Envato Tuts+ Tutorial: [Code an Image Gallery With Glide][published url]
## Instructor: [Chike Mgbemena][instructor url]


Glide is a popular open-source Android library for loading images, videos and animated GIFs. Glide can load and display media from many different sources, such as URL or local directory. Follow along with this tutorial and learn how to use Glide to  create an image gallery app.

------

These are source files for the Envato Tuts+ tutorial: [Code an Image Gallery With Glide][published url]

Available on [Envato Tuts+](https://tutsplus.com). Teaching skills to millions worldwide.

[published url]: http://code.tutsplus.com/tutorials/code-an-image-gallery-android-app-with-glide--cms-28207
[instructor url]: https://tutsplus.com/authors/chike-mgbemena
